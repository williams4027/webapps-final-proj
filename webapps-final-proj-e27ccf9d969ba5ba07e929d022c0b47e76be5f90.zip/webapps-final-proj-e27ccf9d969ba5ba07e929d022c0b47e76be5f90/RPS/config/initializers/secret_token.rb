# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
RPS::Application.config.secret_key_base = '91b3e8dc7c76d47522930ebb3b252ed90aa845bc918ba001c17b020f366388e1595d80563b38f1aed3f36c0171083d6a098272ebb04ab4c281df9e8c29479852'
